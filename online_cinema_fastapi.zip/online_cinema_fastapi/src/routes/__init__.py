from routes.users import router as users_router
from routes.movies.movies import router as movies_router
from routes.movies.favorite_movies import router as favorites_router
from routes.genres import router as genres_router
from routes.movies.comments import router as comments_router
