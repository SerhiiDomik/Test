from storages.interfaces import S3StorageInterface
from storages.s3 import S3StorageClient
