class BaseEmailError(Exception):
    pass
